from django.shortcuts import render

def home(request):
    return render(request, 'website/home.html')

def about(request):
    return render(request, 'website/about.html')

def staff(request):
    return render(request, 'website/staff.html')

def academics(request):
    return render(request, 'website/academics.html')

def projects(request):
    return render(request, 'website/projects.html')

def achievements(request):
    return render(request, 'website/achievements.html')

def contact(request):
    return render(request, 'website/contact.html')

def portal(request):
    return render(request, 'website/portal.html')
