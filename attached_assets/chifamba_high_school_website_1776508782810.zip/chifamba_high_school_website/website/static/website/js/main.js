// Chifamba High School Website - Custom JavaScript
document.addEventListener('DOMContentLoaded', function() {
    console.log('Chifamba High School website loaded successfully.');
    
    // Add smooth scrolling to all links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });
});
